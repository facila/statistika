# fct_sql_stat.pm version 1.32 Juin 2025 par Thierry Le Gall

# $ref_result : référence sur le tableau des résultats
# $ref_text   : reférence sur le texte à analyser
# $filter     : numéro des colonnes à analyser : format x-y,z
# $ref_stat   : référence sur le tableau des valeurs par colonnes , utilisée pour trier
# $init_stat  : si $init_stat alors initialisation à zéro des valeurs de $ref_stat
# $ref_lg     : référence sur le tableau des longueurs pour les valeurs et les nombres
# $init_lg    : si $init_lg alors initialisation des longueurs et retour du tableau

use strict;
require "$ENV{FACILA}/share/prg/fct_utf8.pm";

sub fct_new_lg {
    my ($lg,$value) = @_;
    fct_utf8('decode',\$value); # pour calculer lg avec accents
    my $new_lg = length($value);
    $lg = $new_lg if $new_lg > $lg;
    return $lg }

sub fct_sql_stat {
    my($ref_result,$ref_text,$filter,$ref_stat,$init_stat,$ref_lg,$init_lg) = @_;
    return if ! $ref_text || ! $$ref_text;

    my $column;
    my %filter;
    if ( $filter ) {
    # initialisation des filtres
       if ( $filter =~ /-$/ ) {
          # nombre maximal de colonnes 
          $column = -1;
          for ( split/\n/,$$ref_text ) {
              next if $_ !~ /^\|/;
              foreach (split/\|/) { $column ++ }
              last } }
       for ( split/,/,$filter ) {
           if    ( /(.*)-$/    ) { for ( $1 .. $column ) { $filter{$_} = 1 } }
           elsif ( /(.*)-(.*)/ ) { for ( $1 .. $2      ) { $filter{$_} = 1 } }
           else                                          { $filter{$_} = 1 } } }

    # si pas de longueur , initialisation des variables pour la longueur
    if ( ! $ref_lg ) { my %lg = (); $ref_lg = \%lg; $init_lg = 'init' }

    my($ref_column,$value) = ('')x2;
    my(%nb_value,%all,%stat) = (())x3;
    if ( $init_stat ) {
       # initialisation des valeurs des stats
       foreach $column ( keys %$ref_stat ) {
          $ref_column = $$ref_stat{$column};
          $$ref_lg{$column}{value} = 0 if $init_lg;
          foreach $value ( keys %$ref_column ) {
             $nb_value{$column} ++;
             $stat{$column}{$value} = 0;
             $$ref_lg{$column}{value} = fct_new_lg($$ref_lg{$column}{value},$value) if $init_lg } } }

    # création des tableaux des statistiques
    my @column;
    my $column_old;
    my $line = 0;
    # lecture par ligne
    for ( split/\n/,$$ref_text ) {
       if ( /^\|(.*)/ ) { $_ = $1 } else { next }
       $line ++;
       $column_old = $column = 0;
       # lecture par colonne , séparateur |
       foreach $value (split/\|/) {
          $column_old ++; next if ! $filter{$column_old};
          $column ++;
          if ( $init_lg ) {
             $$ref_lg{$column}{value} = 0 if ! $$ref_lg{$column}{value};
             $$ref_lg{$column}{nb}    = 0 if ! $$ref_lg{$column}{nb} }
          $value = $1 if $value =~ /^ +(.*)/;
          $value = $1 if $value =~ /(.*?) +$/;
          if ( $line == 1 ) {
             push @column , $value;
             $$ref_lg{$column}{value} = fct_new_lg($$ref_lg{$column}{value},$value) if $init_lg }
          else {
             $value = 'NULL' if ! $value;
             $all{$column} ++;
             $nb_value{$column} ++ if ! exists($stat{$column}{$value});
             $stat{$column}{$value} ++;
             if ( $init_lg ) {
                $$ref_lg{$column}{nb}    = length("$nb_value{$column} $all{$column}");
                $$ref_lg{$column}{value} = fct_new_lg($$ref_lg{$column}{value},$value) } } } }

    # mise en forme du résultat
    my($title,$utf8,$lg,$nb,$format,$result) = ('')x6;
    $column = 0;
    for $title ( @column ) {
       $column ++;
       $format = "%-$$ref_lg{$column}{value}s %$$ref_lg{$column}{nb}s\n";
       $result = sprintf $format , $title , "$nb_value{$column}/$all{$column}";
       $ref_column = $stat{$column};
       foreach $value (
	       sort { if ( $ref_stat && exists($$ref_stat{$column}{$a}) && exists($$ref_stat{$column}{$b}) )
	                 { $$ref_stat{$column}{$a} <=> $$ref_stat{$column}{$b} }
	            else { $stat{$column}{$b}      <=> $stat{$column}{$a} } }
          keys %$ref_column ) {
          $utf8    = $value; fct_utf8('decode',\$utf8);
          $lg      = $$ref_lg{$column}{value} + length($value) - length($utf8); # pour adapter la longueur aux cas avec des accents
          $nb      = $stat{$column}{$value};
          $format  = "%-$lg"."s %$$ref_lg{$column}{nb}s\n";
          $result .= sprintf $format , $value , $nb }
       push @$ref_result , $result } }

1;
