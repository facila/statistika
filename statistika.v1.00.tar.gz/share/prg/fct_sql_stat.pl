#!/usr/bin/perl -w

# fct_mysql_stat.pl version 1.00 Octobre 2024 par Thierry Le Gall
#
# statisques sur une table mysql
#
# syntaxe :
# fct_sql_stat.pl MYSQL FILTER
# MYSQL  = texte d'une requête mysql 
# FILTER = colonnes à analyser : x ou x-y ou x- ou des combinaisons séparées par des vigules x,y-z,...
#          si vide alors toutes les colonnes sont analysées

my $dir = "$ENV{FACILA}/share/prg";
require "$dir/fct_sql_stat.pm";
require "$dir/fct_column.pm";

my($mysql,$filter) = @ARGV;
$filter = '' if ! $filter;

my @result;
my $result;
my $i=0;

&fct_sql_stat(\$mysql,\@result,$filter);   # statistiques
&fct_column('title','',\@result,\$result); # mise en forme du résultat : tableau , colonne

print "mysql :\n$mysql\n";
print "filter : $filter\n\n";
print "fct_sql_stat tableau \@result :\n";
foreach ( @result ) { print "$result[$i]\n"; $i++ }
print "fct_column \@result -> \$result :\n";
print $result ;
