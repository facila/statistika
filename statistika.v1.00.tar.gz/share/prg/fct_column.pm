# fct_column.pm version 1.20 Mars 2024 par Thierry LE GALL

# affichage de textes en mode colonne
# affichage standard ou en tableau

use strict;

require "$ENV{FACILA}/share/prg/fct_utf8.pm";

sub fct_column {
    my %col = (); 
    my $ref_text   = ''; # référence sur le texte à traiter
    my $ref_result = ''; # référence sur le résultat
    ( $col{1} , $col{2} , $ref_text , $ref_result ) = @_;
    $col{0} = 0; # nombre d'espaces calculé pour compléter chaque champ
         # $col{1} nombre d'espaces dans la première colonne
         # $col{2} nombre d'espaces entre deux colonnes

    if ( ! $col{1} ) { $col{1} = 1; $col{2} = 3 }
    else {
       if    (   $col{1} eq '-h'              ) { &fct_column_help; return }
       elsif (   $col{1} =~ /^(table|title)$/ ) { $col{2} = 3 }
       elsif (   $col{1} !~ /^\d+$/           ) { $col{1} = 1; $col{2} = 3 }
       elsif ( ! $col{2}                      ) { $col{2} = 3 } }

    my $col     = 0;  # numéro de colonne
    my $nb_col  = 0;  # nombre de colonne
    my $line    = 0;  # numéro de ligne
    my $nb_line = 0;  # nombre de ligne
    my $space   = 0;  # nombre d'espaces de début de colonne
    my @space   = (); # tableau des espaces de début de colonne
    my @lg      = (); # tableau des longueurs du résultat
    my @lg_max  = (); # tableau des longueurs des colonnes
    my @result  = (); # tableau du résultat
    my $separ   = ''; # ligne de séparation pour le mode table ou title
    my $lg      = 0;  # variable tempo
    my $text    = ''; # variable tempo
    my @text    = (); # tableau  tempo

    # calcul de nb_col , nb_line ( 0 à X )
    $nb_col  = @$ref_text - 1;
    foreach ( @$ref_text ) {
       $line = (split/\n/);
       $nb_line = $line if $nb_line < $line }
    $nb_line --;

    # création des tableaux result et space
    foreach $col ( 0 .. $nb_col ) {
       $text  = $$ref_text[$col];
       $text  =~ s/ *\n/\n/g; # suppression des espaces en fin de ligne
       $space = $space[$col] = '';
       @text  = split/\n/,$text;
       foreach $line ( 0 .. $nb_line ) {
          if ( $text[$line] ) {
             $result[$line][$col] = $text[$line];
	     next if $line == 0 && $col{1} eq 'title'; # pas de suppression d'espace en debut de colonne pour la ligne 1
             $space = 0;
             $space = length($1) if $text[$line] =~ /^( *).*/;
             $space[$col] = $space if $space[$col] eq '' || $space < $space[$col] }
          else { $result[$line][$col] = '' }
       $space[$col] = 0 if ! $space[$col] } }

    # suppression des espaces en debut de ligne et calcul de la longueur de colonne
    foreach $col ( 0 .. $nb_col ) {
       $lg_max[$col] = 0;
       foreach $line ( 0 .. $nb_line ) {
          # suppression des espaces en début de ligne , pas de suppression pour la ligne 1
          if ( $line != 0 || $col{1} ne 'title' ) {
             $result[$line][$col] = substr($result[$line][$col],$space[$col]) if $result[$line][$col] && $space[$col] }
          $lg[$line][$col] = 0;
          $text = $result[$line][$col];
          next if ! $text;
          # calcul de longueur de colonne
          &fct_utf8('decode',\$text); # pour calculer lg avec accents
          $lg = length($text);
          $lg[$line][$col] = $lg;
          $lg_max[$col] = $lg if $lg_max[$col] < $lg } }

    # ajout des espaces en fin de ligne pour aligner les colonnes
    foreach $line ( 0 .. $nb_line ) {
       foreach $col ( 0 .. $nb_col ) {
          $col{0} = $lg_max[$col] - $lg[$line][$col];
          $result[$line][$col] .= sprintf "%$col{0}s", '' if $col{0} } }

    # création en mode table du résultat ligne par ligne puis colonne par colonne
    if ( $col{1} =~ /^(table|title)$/ ) {
       foreach $col ( 0 .. $nb_col ) {
          $separ .= "+-" if $col == 0;
          foreach ( 1 .. $lg_max[$col] ) { $separ .= '-' }
          if ( $col != $nb_col ) { $separ .= "-+-" } else { $separ .= "-+" } }
       $separ .= "\n";
       $$ref_result = $separ;

       foreach $line ( 0 .. $nb_line ) {
          $$ref_result .= "| ";
          foreach $col ( 0 .. $nb_col ) {
             $$ref_result .= $result[$line][$col];
             $$ref_result .= " | " if $col != $nb_col }
          $$ref_result .= " |\n";
          $$ref_result .= $separ if $col{1} eq 'title' && $line == 0 }
       $$ref_result .= $separ;
       return;
       }

    # création en mode texte du résultat ligne par ligne puis colonne par colonne
    foreach $line ( 0 .. $nb_line ) {
       $$ref_result .= sprintf "%$col{1}s", '';
       foreach $col ( 0 .. $nb_col ) {
          $$ref_result .= $result[$line][$col];
          $$ref_result .= sprintf "%$col{2}s", '' if $col != $nb_col }
    $$ref_result .= "\n" }
    }

sub fct_column_help {
    print "\n";
    print " affichage de textes en mode colonne\n";
    print "\n";
    print " syntaxe : fct_column c1 c2 ref_text ref_result\n" ;
    print "\n";
    print " affichage standard\n";
    print " c1 : nombre d'espaces dans la première colonne , valeur par défaut = 1\n";
    print " c2 : nombre d'espaces entre deux colonnes      , valeur par défaut = 3\n";
    print "\n";
    print " affichage en tableau\n";
    print " si c1 = table : affichage dans un tableau\n";
    print " si c1 = title : affichage dans un tableau avec un titre sur la première ligne\n";
    print "\n";
    print " ref_text   = référence sur un tableau contenant le texte à afficher\n";
    print " ref_result = référence sur le résultat\n\n" }

1;
