# fct_sql_stat.pm version 1.00 Octobre 2024 par Thierry Le Gall

# $ref_text   : reférence sur le texte à analyser
# $ref_result : référnece sur le tableau des résultats
# $filter     : numéro des colonnes à analyser : format x-y,z

use strict;

sub fct_sql_stat {
    my($ref_text,$ref_result,$filter) = @_;

    my @column;
    my %column;
    my %filter;
    my %stat;
    my($x,$y,$line,$column,$value,$title,$result,$ref_column);

    # nombre maximal de colonnes
    $column = 0;
    for ( split/\n/,$$ref_text ) {
       next if $_ !~ /^\|/;
       foreach (split/\|/) { $column ++ }
       last } 

    if ( $filter ) {
       for ( split/,/,$filter ) {
           if    ( /(.*)-$/    ) { for ( $1 .. $column ) { $filter{$_} = 1 } }
           elsif ( /(.*)-(.*)/ ) { for ( $1 .. $2      ) { $filter{$_} = 1 } }
           else                                          { $filter{$_} = 1 } } }

    # création des tableaux des statistiques  
    for ( split/\n/,$$ref_text ) {
       next if $_ !~ /^\|/;
       $line ++;
       $column = 0;
       foreach $value (split/\|/) {
          chomp $value;
          next if $value eq '';
          $column ++;
          $value = $1 if $value =~ /^ +(.*)/;
          $value = $1 if $value =~ /(.*?) +$/;
          if ( $line == 1 ) {
             push @column , $value;
             $column{$column} = 1 if ! $filter || $filter{$column} }
          elsif ( $value ) { $stat{$column}{$value} ++ if $column{$column} } } }

    $column = 0;
    for $title ( @column ) {
       $column ++;
       next if ! $column{$column};
       $result = "$title\n";
       $ref_column = $stat{$column};
       foreach $value ( sort { $a cmp $b } keys %$ref_column ) {
          $value   = 'NULL' if ! $value;
          $result .= sprintf "%6s %-s\n", $stat{$column}{$value}, $value }
       push @$ref_result , $result } }

1;
