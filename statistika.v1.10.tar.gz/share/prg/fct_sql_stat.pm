# fct_sql_stat.pm version 1.10 Décembre 2024 par Thierry Le Gall

# $ref_result : référence sur le tableau des résultats
# $ref_text   : reférence sur le texte à analyser
# $filter     : numéro des colonnes à analyser : format x-y,z
# $ref_id     : référence sur le tableau des id des valeurs pour trier
# $init       : si $init alors initialisation à zéro des valeurs de $ref_id

use strict;

sub fct_sql_stat {
    my($ref_result,$ref_text,$filter,$ref_id,$init) = @_;
    return if ! $ref_text || ! $$ref_text;

    my($column,$ref_column,$value) = ('')x3;
    my %stat = ();
    if ( $init ) {
       foreach $column ( keys %$ref_id ) {
          $ref_column = $$ref_id{$column};
          foreach $value ( keys %$ref_column ) { $stat{$column}{$value} = 0 } } }

    # nombre maximal de colonnes
    $column = 0;
    for ( split/\n/,$$ref_text ) {
       next if $_ !~ /^\|/;
       foreach (split/\|/) { $column ++ }
       last } 

    my %filter;
    if ( $filter ) {
       for ( split/,/,$filter ) {
           if    ( /(.*)-$/    ) { for ( $1 .. $column ) { $filter{$_} = 1 } }
           elsif ( /(.*)-(.*)/ ) { for ( $1 .. $2      ) { $filter{$_} = 1 } }
           else                                          { $filter{$_} = 1 } } }

    # création des tableaux des statistiques
    my @column;
    my %column;
    my $line = 0;

    for ( split/\n/,$$ref_text ) {
       next if $_ !~ /^\|/;
       $line ++;
       $column = 0;
       foreach $value (split/\|/) {
          chomp $value;
          next if $value eq '';
          $column ++;
          $value = $1 if $value =~ /^ +(.*)/;
          $value = $1 if $value =~ /(.*?) +$/;
          if ( $line == 1 ) {
             push @column , $value;
             $column{$column} = 1 if ! $filter || $filter{$column} }
          elsif ( $value ) { $stat{$column}{$value} ++ if $column{$column} } } }

    my($title,$result) = ('')x2;
    $column = 0;
    for $title ( @column ) {
       $column ++;
       next if ! $column{$column};
       $result = "$title\n";
       $ref_column = $stat{$column};
       foreach $value (
          sort { if ( $ref_id ) { $$ref_id{$column}{$a} <=> $$ref_id{$column}{$b} } else { $stat{$column}{$b} <=> $stat{$column}{$a} } }
          keys %$ref_column ) {
          $value   = 'NULL' if ! $value;
          $result .= sprintf "%6s %-s\n", $stat{$column}{$value}, $value }
       push @$ref_result , $result } }

1;
