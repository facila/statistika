#!/usr/bin/perl -w

sub fct_sql_stat_help {
print "
fct_sql_stat.pl version 2.00 Septembre 2026 par Thierry Le Gall

statisques sur une table mysql

syntaxe :
 fct_sql_stat.pl MYSQL FILTER

 MYSQL  = texte d'une requête mysql 
          si -h : affichage de l'aide
          si -e : exemple avec la table du script

 FILTER = colonnes à analyser : x ou x-y ou x- ou des combinaisons séparées par des virgules x,y-z,...
          si vide : toutes les colonnes sont analysées

";
exit }

sub fct_sql_stat_example {
$filter = '2-';
$mysql  = "
+-----------+---------+-----------+-------------+---------+--------+---------+
| numero    | nom     | prenom    | departement | marque  | modele | couleur |
+-----------+---------+-----------+-------------+---------+--------+---------+
| AB 123 CD | Henri   | Philippe  | Paris       | Renault | Clio   | Blanc   |
| AB 456 CD | Martin  |           | Paris       | Citroen | C4     | Blanc   |
| AB 789 CD | Dupont  | Eric      | Paris       | Peugeot | 308    | Noir    |
| EF 123 GH | Olivier | Catherine | Eure        | Peugeot | 308    | Blanc   |
| EF 456 GH | Lucas   | Eric      | Oise        | Citroen | C3     | Noir    |
| EF 789 GH | Henri   | Valérie   | Nord        | Citroen | C4     | Rouge   |
+-----------+---------+-----------+-------------+---------+--------+---------+";
} 

################################################

$dir = "$ENV{FACILA}/share/prg";
($mysql,$filter) = @ARGV;
exit if ! $mysql;

if    ( $mysql eq '-h' ) { fct_sql_stat_help }
elsif ( $mysql eq '-e' ) { fct_sql_stat_example }
else  { $filter = '' if ! $filter }

require "$dir/fct_sql_stat.pm";
require "$dir/fct_column.pm";

$result = '';
@result = ();

fct_sql_stat(\@result,\$mysql,$filter)  ; # statistiques
fct_column('title','',\@result,\$result); # mise en forme du résultat : tableau , colonne

print "filter : $filter\n";
print "mysql  : $mysql\n\n";
print "fct_sql_stat tableau \@result :\n";
$i = 0;
foreach ( @result ) { print "$result[$i]\n"; $i++ }
print "fct_column \@result -> \$result :\n";
print $result ;
